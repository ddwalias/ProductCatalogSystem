import{l as o,a as r}from"../chunks/CYpSNn-a.js";export{o as load_css,r as start};
